from .module1 import function_name
