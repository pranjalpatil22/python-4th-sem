# mymodule.py

def add(a, b):
    return a + b

def is_even(number):
    return number % 2 == 0
